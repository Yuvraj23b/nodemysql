const Express = require('express')
const mysql = require('mysql2');
const route = Express.Router()

route.post('/',(req,res)=>{
    async function getData(){
        console.log(req.body)
        try{
        }catch(err){
            res.status(500).json(err)
        }
    }
    getData();
})

route.get('/',async (req,res)=>{
    try{
        //console.log(req.query.hid)
    }catch(err){
        res.status(400).json(err)
        //res.status(500).json(err)
    }
})

route.get('/fetch',async (req,res)=>{
    try{
        //console.log(req.query.hid,"hii")
    }catch(err){
        res.status(400).json(err)
        //res.status(500).json(err)
    }
})

route.get('/test', async (req,res)=>{
    try{
    }catch(err){
        res.status(400).json(err)
        //res.status(500).json(err)
    }
})

module.exports = route;