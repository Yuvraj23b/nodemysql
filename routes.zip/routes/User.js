const Express = require('express')
const mysql = require('mysql2');

const route = Express.Router()

route.get('/',async (req,res)=>{

})

route.post('/',async (req,res)=>{
    try{
    }catch(err){
    }
})

module.exports = route;

